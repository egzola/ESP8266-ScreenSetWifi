/* 
  Developed by:  Eduardo Zola - Zola Lab 2015 - www.zolalab.com.br - egzola@gmail.com

  Screen Set Wifi Library
  Copyright (c) 2015 Eduardo Zola.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.
*/

String getValue(String data, char separator, int index) {
    int found = 0;
    int strIndex[] = {
        0,
        -1
    };
    int maxIndex = data.length() - 1;
    for (int i = 0; i <= maxIndex && found <= index; i++) {
        if (data.charAt(i) == separator || i == maxIndex) {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i + 1 : i;
        }
    }
    return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}


boolean getData(int LDR_PIN,void (*func)(), char *xssid, char *xpwd, boolean DEBUG) {
    pinMode(LDR_PIN, INPUT);
    
    const int timeOut = 700;

    unsigned long t = 0;
    unsigned long delta = 0;

    String txt = "";
    boolean sig = false;
    unsigned char c = 0x00;
    boolean init_capture = false;
    int bitCount = 0;

    pinMode(LDR_PIN, INPUT);

        yield();

        if(DEBUG) Serial.println("\nWaiting...\n\r");
        while (!digitalRead(LDR_PIN)) yield();

        txt = "";
        c = 0x00;
        bitCount = 0;
        init_capture = false;

        while (true)
        {
            yield();
            delta = 0;
            t = millis();
            sig = digitalRead(LDR_PIN);
            while (digitalRead(LDR_PIN) == sig && delta < timeOut) {
                delta = millis() - t;
                yield();
            };
            if (delta > 3 && delta < 150) {
                if (sig) bitSet(c, 7 - bitCount);
                bitCount++;

                if (bitCount == 8) {
                    //           if(DEBUG)   Serial.print(char(c));
                    if (c == '>' && !init_capture) {
                        init_capture = true;
                        if(DEBUG) Serial.println("\n\n\r*** BEGIN ***");
                        func();
                    }

                    if (init_capture) {
                        txt += String(char(c));
                        if(DEBUG) Serial.print(char(c));
                    }

                    bitCount = 0;
                    c = 0x00;
                }
            }
            if (delta >= timeOut) break;
        }

        if (delta >= timeOut && init_capture) {
            int sz = txt.length() - 1;
            unsigned int calc = 0;
            unsigned char crc;
            unsigned char crc_rec = txt.charAt(sz);

            int v1 = txt.charAt(0);
            int v2;
            for (int i = 1; i < sz; i++) {
                v2 = txt.charAt(i);
                if (v2 > v1) calc += (v2 - v1);
                else calc += (v1 - v2);
                if (calc > 255) calc -= 255;
                v1 = v2;
            }
            crc = calc;

            if(DEBUG) Serial.println("");
            if(DEBUG) Serial.println("Checksum: " + String(crc_rec));

            if (crc == crc_rec && crc > 0) {
                txt = txt.substring(1, txt.length() - 1); 

                String s_ssid = getValue(txt, '\n', 0);
                String s_pwd = getValue(txt, '\n', 1);

                if(DEBUG) Serial.println("Checksum status: OK");
                if(DEBUG) Serial.println("ssid: " + s_ssid);
                if(DEBUG) Serial.println("pwd: " + s_pwd);

                if(DEBUG) Serial.println("*** END ***");

                int sz;
                sz = s_ssid.length() + 1;
                s_ssid.toCharArray(xssid, sz);
                
                sz = s_pwd.length() + 1;
                s_pwd.toCharArray(xpwd, sz);
                return(true);
                
            } else {
                if(DEBUG) Serial.println("CRC ERROR");
                txt = "";
                return(false);
            }
        }
        return(false);
}





